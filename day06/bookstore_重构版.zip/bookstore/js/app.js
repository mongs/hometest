angular.module('bookStoreApp', ['ngRoute','routeApp','filterApp','ctrlApp'])
	
	
	
//JSON.parse()
/*
href="javascript:history.back()"  返回
				
history.forward() 	前进
				
history.go(-2)
				
href="tel:10086" 打电话
				
href="msg:" 	发短信
				
*/